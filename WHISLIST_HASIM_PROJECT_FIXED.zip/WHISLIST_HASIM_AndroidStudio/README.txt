WHISLIST HASIM Android Studio source.
Contains offline HTML app with embedded looping music and transparent launcher icon.
Build APK using GitHub Actions workflow supplied separately: upload this project ZIP to repository root,
and place workflow YAML in .github/workflows/build-apk.yml.
App launcher label: WHISLIST HASIM.
