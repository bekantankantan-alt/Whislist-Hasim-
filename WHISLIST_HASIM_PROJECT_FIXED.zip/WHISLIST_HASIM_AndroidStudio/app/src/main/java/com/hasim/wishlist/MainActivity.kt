package com.hasim.wishlist

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.util.Base64
import android.webkit.JavascriptInterface
import java.io.OutputStream
import android.os.Bundle
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.view.Window
import android.view.WindowManager

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserRequestCode = 501
    private val folderChooserRequestCode = 502
    private var storageTreeUri: Uri? = null

    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)

        webView = WebView(this)
        webView.setBackgroundColor(0xFF07162E.toInt())
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(StorageBridge(), "NativePhotoStore")
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                // Close any previous picker callback to avoid leaving WebView waiting.
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback

                val pickerIntent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "image/*"
                }
                try {
                    startActivityForResult(Intent.createChooser(pickerIntent, "Pilih foto"), fileChooserRequestCode)
                } catch (e: Exception) {
                    fileChooserCallback?.onReceiveValue(null)
                    fileChooserCallback = null
                    return false
                }
                return true
            }
        }

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.loadsImagesAutomatically = true
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == folderChooserRequestCode) {
            if (resultCode == Activity.RESULT_OK) {
                val uri = data?.data
                if (uri != null) {
                    storageTreeUri = uri
                    try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {}
                    try { createHiddenNoMedia(uri) } catch (_: Exception) {}
                    webView.evaluateJavascript("window.onPhotoFolderChosen && window.onPhotoFolderChosen(${org.json.JSONObject.quote(uri.toString())})", null)
                }
            } else webView.evaluateJavascript("window.onPhotoFolderCancelled && window.onPhotoFolderCancelled()", null)
            return
        }
        if (requestCode == fileChooserRequestCode) {
            val callback = fileChooserCallback ?: return
            fileChooserCallback = null

            val results: Array<Uri>? = if (resultCode == Activity.RESULT_OK) {
                val clipData = data?.clipData
                when {
                    clipData != null -> Array(clipData.itemCount) { i -> clipData.getItemAt(i).uri }
                    data?.data != null -> arrayOf(data.data!!)
                    else -> null
                }
            } else null
            callback.onReceiveValue(results)
        }
    }

    private fun createHiddenNoMedia(tree: Uri) {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        val cursor = contentResolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)
        var exists = false
        cursor?.use { while (it.moveToNext()) if (it.getString(1) == ".nomedia") exists = true }
        if (!exists) DocumentsContract.createDocument(contentResolver, DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree)), "application/octet-stream", ".nomedia")
    }

    inner class StorageBridge {
        @JavascriptInterface fun chooseFolder() {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                startActivityForResult(intent, folderChooserRequestCode)
            }
        }
        @JavascriptInterface fun getFolder(): String = storageTreeUri?.toString() ?: getPreferences(MODE_PRIVATE).getString("photo_tree", "") ?: ""
        @JavascriptInterface fun savePhoto(base64: String, filename: String): String {
            val tree = storageTreeUri ?: run {
                val saved = getPreferences(MODE_PRIVATE).getString("photo_tree", "")
                if (saved.isNullOrEmpty()) return ""
                Uri.parse(saved)
            }
            return try {
                val safeName = filename.replace(Regex("[^A-Za-z0-9_.-]"), "_").take(80).ifBlank { "wishlist_photo.jpg" }
                val child = DocumentsContract.createDocument(contentResolver, DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree)), "image/jpeg", safeName) ?: return ""
                val bytes = Base64.decode(base64.substringAfter(","), Base64.DEFAULT)
                contentResolver.openOutputStream(child, "w")?.use { it.write(bytes) } ?: return ""
                grantUriPermission(packageName, child, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                child.toString()
            } catch (_: Exception) { "" }
        }
        @JavascriptInterface fun persistFolder(uri: String) {
            getPreferences(MODE_PRIVATE).edit().putString("photo_tree", uri).apply()
            storageTreeUri = Uri.parse(uri)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
